# Ebook-Projeto
Esse ebook foi criado por IA  para um projeto 
Projeto EBOOK Gerado por I.A.s
ℹ️ NOTE: Este é o repositório desenvolvido durante o curso no qual fui instrutor técnico na plataforma da DIO

Projeto com o objetivo de gerar um ebook digital com as facilidades das ferramentas de IA. todos os prompts seguem abaixo.

📕Clique aqui para ler

💻 Tecnologias utilizadas no projeto
ChatGPT
MidJourney
PowerPoint
🧠 Prompts
ChatGPT：

Ação	prompt
título	Crie um título de um ebook sobre o tema de css, o ebookk é do nicho de programação e o subnicho é de css, o título deve ser épico e curto, e tenha uma temática de star wars no título, me liste 5 variações de títulos
conteúdo	Faça um texto para ebook , com foco em CSS, listando os principais seletores CSS com exemplos em código {REGRAS} Explique sempre de uma maneira simples Deixe o texto enxuto, Sempre traga exemplos de código em contextos reais , sempre deixe um título sugestivo por tópico
Midjourney：

Ação	prompt
título	A jedi in meditation pose, with your blue lightsaber floating, pixel art style --v 5.1
✨ Features
Conteúdo gerado via ChatGPT
Imagens geradas via MidJourney
📚 Materiais
Imagens utilizadas em assets
ebook gerado durante as aulas em output
🛠️ Instruções de execução
Utilize os prompts acima nas ferramentas sugeridas para gerar o material base e utilize uma ferramenta de edição de documentos como power point, libreoffice , indesign para diagramação.
